package com.admin.scholarship.model;


import java.util.List;

public class ScholarshipsFormWrapper {

    private List<Scholarship> scholarships;

    public List<Scholarship> getScholarships() {
        return scholarships;
    }

    public void setScholarships(List<Scholarship> scholarships) {
        this.scholarships = scholarships;
    }
}

