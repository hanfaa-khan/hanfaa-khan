package com.admin.scholarship.controller;

import com.admin.scholarship.model.Scholarship;
import com.admin.scholarship.model.ScholarshipsFormWrapper;
import com.admin.scholarship.repository.ScholarshipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
public class ScholarshipController {

    @Autowired
    private ScholarshipRepository scholarshipRepository;

    // ✅ Show student card view (home.html)
    @GetMapping("/home")
    public String viewScholarshipCards(Model model) {
        List<Scholarship> scholarships = scholarshipRepository.findAll();
        model.addAttribute("scholarships", scholarships);
        return "student/home";  // ✔️ This will load templates/student/home.html
    }

    // ✅ Show admin editable table view (schemes.html)
    @GetMapping("/schemes")
    public String showSchemes(Model model) {
        List<Scholarship> scholarships = scholarshipRepository.findAll();
        ScholarshipsFormWrapper wrapper = new ScholarshipsFormWrapper();
        wrapper.setScholarships(scholarships);
        model.addAttribute("scholarshipsFormWrapper", wrapper);
        return "admin/schemes";  // ✔️ This will load templates/admin/schemes.html
    }

    @PostMapping("/schemes/update")
    public String updateSchemes(@ModelAttribute ScholarshipsFormWrapper scholarshipsFormWrapper) {
        scholarshipRepository.saveAll(scholarshipsFormWrapper.getScholarships());
        return "redirect:/schemes";
    }

    @GetMapping("/addscheme")
    public String showAddSchemeForm(Model model) {
        model.addAttribute("scholarship", new Scholarship());
        return "admin/addscheme";  // ✔️ Assuming it's in templates/admin/
    }

    @PostMapping("/addscheme")
    public String addScheme(@ModelAttribute Scholarship scholarship) {
        scholarshipRepository.save(scholarship);
        return "redirect:/schemes";
    }
}