package com.admin.scholarship.controller;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.admin.scholarship.model.Login;
import com.admin.scholarship.repository.LoginRepository;

@Controller
public class RegisterController {

    @Autowired
    private LoginRepository loginRepository;

    @GetMapping("/register")
    public String showRegisterForm() {
        return "register";
    }

    @PostMapping("/register")
    public String processRegister(
            @RequestParam("studentId") Long studentId,
            @RequestParam("email") String email,
            @RequestParam("password") String password,
            @RequestParam("confirmPassword") String confirmPassword,
            Model model) {

        if (!password.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match.");
            return "register";
        }

        // Optional: Check for existing email
        if (loginRepository.findByEmail(email) != null) {
            model.addAttribute("error", "Email already registered.");
            return "register";
        }

        Login newLogin = new Login();
        newLogin.setId(studentId);
        newLogin.setEmail(email);
        newLogin.setPassword(password); // ⚠️ Consider encrypting

        loginRepository.save(newLogin);
        return "redirect:/login";
    }
}

