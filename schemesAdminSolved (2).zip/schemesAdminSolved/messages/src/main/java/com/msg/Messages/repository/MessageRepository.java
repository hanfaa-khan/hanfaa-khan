package com.msg.Messages.repository;

import com.msg.Messages.model.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageRepository extends JpaRepository<Message, Long> {
}
