package com.admin.scholarship;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.cloud.client.discovery.EnableDiscoveryClient;


@EnableDiscoveryClient
@SpringBootApplication
public class ScholarshipDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScholarshipDashboardApplication.class, args);
	}

}
